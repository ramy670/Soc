
import static java.lang.System.currentTimeMillis;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GameApp {

    static public final int SERVER = 1;
    static public final int CLIENT = 2;
    static public final int UDP = 1;
    static public final int TCP = 2;
    private static final String zeroTo255 = "([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])"; //source: farenda.com
    static int type = 0;
    static int protocol = 0;
    static int wellKnownPort = 2000;
    static Scanner scan = new Scanner(System.in);
    static String host;
    private static final int timeout = 16000;
    private static Random rand = new Random();

    static int _nextInt() {
        while (true) {
            String line = scan.nextLine();
            if (isNum(line)) {
                return Integer.parseInt(line);
            } else {
                System.out.println("Please enter an integer!");
            }
        }
    }

    static String _nextString() {
        String line = scan.nextLine();
        return line;
    }

    public static void main(String[] args) throws IOException {
        do {
            System.out.print("(1) Server or (2) client? > ");
            type = _nextInt();
        } while (type != SERVER && type != CLIENT);

        if (type == SERVER) {
            System.out.print("Server port: ");
            wellKnownPort = _nextInt();
        } else {
        	String IP_REGEXP = zeroTo255 + "\\." + zeroTo255 + "\\."  //source: farenda.com
                    + zeroTo255 + "\\." + zeroTo255;
            do{
            	System.out.print("Host (IP-address or localhost): ");
            	host = _nextString();
            }while(!host.matches(IP_REGEXP) && !(host=host.toLowerCase()).equals("localhost"));
            //System.out.println(host);
            System.out.print("Server port: ");
            wellKnownPort = _nextInt();

        }

        do {
            System.out.print("(1) UDP or (2) TCP? > ");
            protocol = _nextInt();
        } while (protocol != UDP && protocol != TCP);

        if (type == SERVER) {
            if (protocol == UDP) {
                udpServer(wellKnownPort);
            } else {
                tcpServer(wellKnownPort);
            }
        } else if (protocol == UDP) {
            udpClient();
        } else {
            tcpClient();
        }

    }

    private static boolean isNum(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static void udpServer(int port) {
        // Put your udp server code here
        System.out.println("UDP server running at port " + port);
        DatagramSocket socket;
        try {
            socket = new DatagramSocket(port);
            boolean newClient = false;
            DatagramPacket request = null;

            while (true) {
                if (!newClient) {
                    request = new DatagramPacket(new byte[5], 5);
                    socket.receive(request);
                }
                newClient = false;
                long waitTime = 0;
                long timeAtLastReq = currentTimeMillis();

                DatagramPacket response;
                InetAddress clientAddress = request.getAddress();
                int clientPort = request.getPort();
                String hello = new String(request.getData());
                if (hello.toUpperCase().equals("HELLO")) {
                    System.out.println("Connection successful");
                    response = new DatagramPacket("WELCOME".getBytes(), "WELCOME".getBytes().length, clientAddress, clientPort);
                    socket.send(response);
                    int nr = rand.nextInt(101);
                    boolean game = true;
                    String guess = "";
                    while (game) {

                        request = new DatagramPacket(new byte[5], 5);

                        socket.receive(request);
                        guess = new String(request.getData());
                        guess = guess.trim();
                        waitTime = currentTimeMillis() - timeAtLastReq;

                        if (waitTime > timeout) {
                            if (isNum(guess)) { //At the beginning we checked identity with IP, but since we run everything on localhost the server mistook everything to be coming from the last connected client and did not know it was another, thus we opted to check identity (if new or same client) by checking the data type sent.                              
                            	System.out.println("Last client timed out.");
                                DatagramPacket response2 = new DatagramPacket("TO".getBytes(), "TO".getBytes().length, clientAddress, clientPort);
                                socket.send(response2);
                                break;
                            } else {
                                newClient = true;
                                break;
                            }
                        }
                        if (waitTime < timeout) {
                            if (!isNum(guess)) {
                                System.out.println("Another client trying to connect. Busy will be sent");
                                DatagramPacket response2 = new DatagramPacket("BUSY".getBytes(), "BUSY".getBytes().length, request.getAddress(), request.getPort());
                                socket.send(response2);

                            } else {
                                timeAtLastReq = currentTimeMillis();

                                if (isNum(guess) && Integer.valueOf(guess) == nr) {
                                    socket.send(new DatagramPacket("CORRECT".getBytes(), "CORRECT".getBytes().length, clientAddress, clientPort));
                                    System.out.println("Looking for new client");
                                    game = false;

                                } else if (isNum(guess) && Integer.valueOf(guess) > nr) {
                                    socket.send(new DatagramPacket("HI".getBytes(), 2, clientAddress, clientPort));
                                } else if (isNum(guess) && Integer.valueOf(guess) < nr) {
                                    socket.send(new DatagramPacket("LO".getBytes(), 2, clientAddress, clientPort));
                                } else {
                                    System.out.println("Unknown command sent");
                                }
                            }
                        }

                    }
                } else {
                    DatagramPacket response2 = new DatagramPacket("NA".getBytes(), "NA".getBytes().length, request.getAddress(), request.getPort());
                    socket.send(response2);
                    //response = new DatagramPacket(resp.getBytes(), resp.getBytes().length, clientAddress, clientPort);
                }
            }

        } catch (SocketException e2) {
            // TODO Auto-generated catch block
            //e2.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            //e.printStackTrace();
            System.out.println("IO Exception"); //Vad mer??
        }

    }

    static void tcpServer(int port) {
        ServerSocket serverSocket = null;
        PrintWriter out = null;
        BufferedReader in = null;
        Socket clientSocket = null;
        /*try {
            serverSocket = new ServerSocket(port);
        } catch (IOException ex) {
            System.out.println("IOException");
        }*/

        while (true) {
            try {
            	serverSocket = new ServerSocket(port);
                System.out.println("TCP server running at port " + port);
                boolean connected = true;
                clientSocket = serverSocket.accept();

                clientSocket.setSoTimeout(timeout);

                System.out.println("Waiting for input.....");
                out = new PrintWriter(clientSocket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                String inputLine = "";
                while (connected) {
                    try {
                        inputLine = in.readLine();
                        System.out.println("Input: " + inputLine);
                    } catch (SocketTimeoutException exeption) {
                        System.out.println("Client disconnected.");
                        break;
                    }
                    if (inputLine.toUpperCase().equals("HELLO")) {

                        System.out.println("Connection successful");
                        out.println("WELCOME");
                        int nr = rand.nextInt(101);
                        boolean game = true;
                        while (game) {
                            System.out.println("New game loop");
                            try {
                                inputLine = in.readLine();
                                if (inputLine == null) {
                                    System.out.println("Client disconnected");
                                    connected = false;
                                    break;
                                }
                                System.out.println("Client says: " + inputLine);
                            } catch (SocketException | SocketTimeoutException exeption) {
                                System.out.println("Client disconnected");
                                connected = false;
                                break;
                            }
                            if (isNum(inputLine) && Integer.valueOf(inputLine) == nr) {
                                out.println("CORRECT");
                                System.out.println("Looking for new client");
                                game = false;
                                connected = false;
                            }
                            if (isNum(inputLine) && Integer.valueOf(inputLine) > nr) {
                                out.println("HI");
                            }
                            if (isNum(inputLine) && Integer.valueOf(inputLine) < nr) {
                                out.println("LO");
                            }
                        }
                    } else {
                        out.println("NA");
                        break;
                    }

                }

            } catch (SocketException e) {
                System.out.println("SocketException");
            } catch (java.net.SocketTimeoutException e) {
                System.out.println("Timeout!");

            } catch (IOException e) {
                System.out.println("IOException");
            } finally {
                try {
                    System.out.println("Disconnecting last cleint");
                    if (clientSocket != null) {

                        clientSocket.close();
                    }
                    if (out != null) {
                        out.close();
                    }
                    if (in != null) {
                        in.close();
                    }
                    if (serverSocket != null) {
                    	serverSocket.close();
                    }
                    System.out.println("Last cleint disconnected");

                } catch (IOException ex) {
                    System.out.println("IOException 2");
                    Logger.getLogger(GameApp.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    static void udpClient() {
    	DatagramSocket socket = null;
        System.out.println("UDP client");
        try {
            InetAddress address = InetAddress.getByName(host);
            socket = new DatagramSocket();
            while (true) {
                System.out.println("Greet server!");
                byte[] toSend = _nextString().toUpperCase().getBytes();

                DatagramPacket request = new DatagramPacket(toSend, toSend.length, address, wellKnownPort);
                socket.send(request);

                byte[] buffer = new byte[7];
                DatagramPacket response = new DatagramPacket(buffer, buffer.length);
                socket.receive(response);

                String answer = new String(response.getData());
                answer = answer.trim();
               // System.out.println(answer + " lngth: " + answer.length());
                if (answer.equals("BUSY")) {
                    System.out.println("Server busy:");
                    continue;
                } else if (answer.equals("WELCOME")) {
                    boolean guessed = false;
                    long lastTime;
                    long waitTime;
                    while (!guessed) {
			lastTime = currentTimeMillis();
                        System.out.println("Propose a solution");
                        int proposal = _nextInt();
			waitTime =   currentTimeMillis() - lastTime;
                       /* if (waitTime>(timeout-1000)) {
                            System.out.println("Server timout.");
                            break;
                        }*/
                        if (proposal <= 0 || proposal >= 100) {
                            System.out.println("Only > 0 and < 100");
                            continue;
                        } else {
                            request = new DatagramPacket(Integer.toString(proposal).getBytes(), Integer.toString(proposal).getBytes().length, address, wellKnownPort); //Check 3 doesnt cause problem
                            socket.send(request);
                            response = new DatagramPacket(new byte[7], 7);
                            socket.receive(response);
                            String result = new String(response.getData());
                            result = result.trim();
                            if (result.equals("HI")) {
                                System.out.println("Smaller");
                            } else if (result.equals("LO")) {
                                System.out.println("Larger");
                            }
                            if (result.equals("CORRECT")) {
                                System.out.println("Correct");
                                guessed = true;
                            }
                            if (result.equals("TO")) {
                                System.out.println("Server timout.");
                                break;
                            }

                        }
                    }
                } else if (answer.equals("NA")) {
                    System.out.println("Unknown command.");
                    continue;
                }

                System.out.println("Waiting for 3 seconds");
                Thread.sleep(3000);
            }

        } catch (SocketTimeoutException ex) {
            System.out.println("Timeout error: " + ex.getMessage());
            ex.printStackTrace();
        } catch (IOException ex) {
            System.out.println("Client error: " + ex.getMessage());
            ex.printStackTrace();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        finally {
        	if(socket != null) {
        		socket.close();
        	}
        }

    }

    static void tcpClient() {
        // Put your tcp client code here
        System.out.println("TCP client.");
        Socket tcpServerSocket = null;
        PrintWriter out = null;
        BufferedReader in = null;
        try {
            while (true) {
                try {
                    tcpServerSocket = new Socket(host, wellKnownPort);
                    out = new PrintWriter(tcpServerSocket.getOutputStream(), true);
                    in = new BufferedReader(new InputStreamReader(tcpServerSocket.getInputStream()));
                    tcpServerSocket.setSoTimeout(timeout);
                } catch (IOException ex) {
                    System.out.println("IOException Happened");
                    if (tcpServerSocket != null) {
                        tcpServerSocket.close();
                    }
                    if (out != null) {
                        out.close();
                    }
                    if (in != null) {
                        in.close();
                    }

                }

                System.out.println("Greet server!");
                out.println(_nextString().toUpperCase());
                String answer = "";

                try {
                    answer = in.readLine();
                } catch (SocketException exept) {
                    System.out.println("Server disconnected (Most likley timeout)");
                    continue;
                } catch (java.net.SocketTimeoutException exep) {
                    System.out.println("Busy");
                    continue;
                } catch (IOException ex) {
                    System.out.println("IO Error");

                    Logger.getLogger(GameApp.class.getName()).log(Level.SEVERE, null, ex);
                }
                boolean timeout = false;
                if (timeout) {
                    System.out.println("Server busy:");
                    continue;
                } else if (answer.equals("WELCOME")) {
                    boolean gameRunning = false;
                    while (!gameRunning) {
                        System.out.println("Propose a solution");
                        int proposal = _nextInt();
                        if (proposal < 0 || proposal > 100) {
                            System.out.println("Only > 0 and < 100");
                            continue;
                        } else {

                            out.println(proposal);
                            try {
                                answer = in.readLine();

                            } catch (java.net.SocketTimeoutException exep) {
                                try {
                                    tcpServerSocket.close();
                                    out.close();
                                    in.close();

                                    System.out.println("Timeout. Disconnecting.");
                                    Thread.sleep(3000);
                                } catch (IOException ex) {
                                    Logger.getLogger(GameApp.class.getName()).log(Level.SEVERE, null, ex);
                                } catch (InterruptedException ex) {
                                    System.out.println("Connection was interrupted (possibly timeout).");

                                    //Logger.getLogger(GameApp.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                gameRunning = false;
                            } catch (SocketException ex) {
                                System.out.println("Timeout.");
                                break;
                            } catch (IOException ex) {
                                Logger.getLogger(GameApp.class.getName()).log(Level.SEVERE, null, ex);
                            }

                            String result = new String(answer);
                            result = result.trim();
                            if (result.equals("HI")) {
                                System.out.println("Smaller");
                            } else if (result.equals("LO")) {
                                System.out.println("Larger");
                            } else if (result.equals("CORRECT")) {
                                System.out.println("Correct");
                                gameRunning = true;

                            } else if (result.equals("TO")) {
                                System.out.println("'Timeout. Exiting current game.");
                                gameRunning = true;

                            }
                        }
                    }

                    System.out.println("Waiting for 3 seconds");
                    try {
                        tcpServerSocket.close();
                        out.close();
                        in.close();

                        Thread.sleep(3000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(GameApp.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {

                        Logger.getLogger(GameApp.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else if (answer.equals("NA")) {
                    System.out.println("Unknown command.");
                    continue;
                }

            }
        } catch (Exception exceptio) {
            System.out.println("Connection error.");
        } finally {
            try {
                tcpServerSocket.close();
                out.close();
                in.close();

                System.out.println("Timeout. Disconneting.");
                Thread.sleep(3000);
            } catch (IOException ex) {
                Logger.getLogger(GameApp.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InterruptedException ex) {
                Logger.getLogger(GameApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
